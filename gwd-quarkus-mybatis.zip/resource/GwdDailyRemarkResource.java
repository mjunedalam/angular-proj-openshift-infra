package com.example.gwd.resource;

import com.example.gwd.dto.*;
import com.example.gwd.service.GwdDailyRemarkService;

import jakarta.inject.Inject;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;

@Path("/gwd-daily-remarks")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class GwdDailyRemarkResource {

    @Inject
    GwdDailyRemarkService service;

    @POST
    public GwdDailyRemarkResponse create(GwdDailyRemarkRequest req) {
        return service.create(req);
    }

    @PUT
    public GwdDailyRemarkResponse update(GwdDailyRemarkRequest req) {
        return service.update(req);
    }

    @DELETE
    @Path("/{id}")
    public GwdDailyRemarkResponse delete(@PathParam("id") Long id) {
        return service.delete(id);
    }
}
