package com.example.gwd.service;

import com.example.gwd.dto.*;
import com.example.gwd.mapper.GwdDailyRemarkMapper;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

import java.util.HashMap;
import java.util.Map;

@ApplicationScoped
public class GwdDailyRemarkService {

    @Inject
    GwdDailyRemarkMapper mapper;

    public GwdDailyRemarkResponse create(GwdDailyRemarkRequest req) {

        Map<String, Object> params = new HashMap<>();
        params.put("epANum", req.epANum);
        params.put("wActDt", req.wActDt);
        params.put("area", req.area);
        params.put("status", req.status);
        params.put("wOpRmk", req.wOpRmk);
        params.put("nxt24HrPlanRmk", req.nxt24HrPlanRmk);
        params.put("wDrlgSmryRmk", req.wDrlgSmryRmk);
        params.put("doCommit", "Y");

        mapper.insertGwdDailyRemark(params);

        GwdDailyRemarkResponse res = new GwdDailyRemarkResponse();
        res.egdrId = (Long) params.get("egdrId");
        res.returnValue = (String) params.get("returnValue");

        return res;
    }

    public GwdDailyRemarkResponse update(GwdDailyRemarkRequest req) {

        Map<String, Object> params = new HashMap<>();
        params.put("epANum", req.epANum);
        params.put("wActDt", req.wActDt);
        params.put("area", req.area);
        params.put("status", req.status);
        params.put("wOpRmk", req.wOpRmk);
        params.put("nxt24HrPlanRmk", req.nxt24HrPlanRmk);
        params.put("wDrlgSmryRmk", req.wDrlgSmryRmk);
        params.put("egdrId", req.egdrId);
        params.put("doCommit", "Y");

        mapper.updateGwdDailyRemark(params);

        GwdDailyRemarkResponse res = new GwdDailyRemarkResponse();
        res.returnValue = (String) params.get("returnValue");

        return res;
    }

    public GwdDailyRemarkResponse delete(Long egdrId) {

        Map<String, Object> params = new HashMap<>();
        params.put("egdrId", egdrId);
        params.put("doCommit", "Y");

        mapper.deleteGwdDailyRemark(params);

        GwdDailyRemarkResponse res = new GwdDailyRemarkResponse();
        res.returnValue = (String) params.get("returnValue");

        return res;
    }
}
