package com.example.gwd.mapper;

import org.apache.ibatis.annotations.Mapper;
import java.util.Map;

@Mapper
public interface GwdDailyRemarkMapper {

    void insertGwdDailyRemark(Map<String, Object> params);

    void updateGwdDailyRemark(Map<String, Object> params);

    void deleteGwdDailyRemark(Map<String, Object> params);
}
