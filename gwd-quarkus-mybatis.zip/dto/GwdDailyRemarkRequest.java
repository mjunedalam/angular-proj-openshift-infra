package com.example.gwd.dto;

import java.time.LocalDate;

public class GwdDailyRemarkRequest {

    public String epANum;
    public LocalDate wActDt;
    public String area;
    public String status;
    public String wOpRmk;
    public String nxt24HrPlanRmk;
    public String wDrlgSmryRmk;
    public Long egdrId;
}
