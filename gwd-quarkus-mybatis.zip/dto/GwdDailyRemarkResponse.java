package com.example.gwd.dto;

public class GwdDailyRemarkResponse {
    public Long egdrId;
    public String returnValue;
}
