package com.example.gwd.util;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Date;
import java.util.TimeZone;

public final class DateUtil {

    public static final DateTimeFormatter ISO_DATE = DateTimeFormatter.ISO_LOCAL_DATE;

    private DateUtil() {}

    public static boolean isValid(String raw) {
        if (raw == null || raw.isBlank()) return false;
        try {
            LocalDate.parse(raw, ISO_DATE);
            return true;
        } catch (DateTimeParseException e) {
            return false;
        }
    }

    public static LocalDate parse(String raw) {
        return LocalDate.parse(raw, ISO_DATE);
    }

    public static Date toOracleDate(LocalDate date) {
        return Date.from(date.atStartOfDay(TimeZone.getDefault().toZoneId()).toInstant());
    }

    public static String format(LocalDate date) {
        return date.format(ISO_DATE);
    }
}
