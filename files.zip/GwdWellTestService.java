package com.example.gwd.service;

import com.example.gwd.dto.ApiResponse;
import com.example.gwd.dto.GwdWellTestRequest;
import com.example.gwd.mapper.GwdWellTestMapper;
import com.example.gwd.util.DateUtil;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import org.jboss.logging.Logger;

import java.util.HashMap;
import java.util.Map;

@ApplicationScoped
public class GwdWellTestService {

    private static final Logger LOG        = Logger.getLogger(GwdWellTestService.class);
    private static final String DO_COMMIT  = "Y";

    @Inject
    GwdWellTestMapper wellTestMapper;

    // ── INSERT ────────────────────────────────────────────────────────────────

    public ApiResponse<Long> insert(GwdWellTestRequest req) {

        if (req == null)
            return ApiResponse.error(400, "Request body is required");

        if (!DateUtil.isValid(req.wTestStaDt()))
            return ApiResponse.error(400,
                    "Invalid wTestStaDt '%s'. Use yyyy-MM-dd".formatted(req.wTestStaDt()));

        try {
            Map<String, Object> params = buildInsertParams(req);
            wellTestMapper.insertGwdWellTest(params);

            String oracleError = (String) params.get("returnValue");
            if (oracleError != null && !oracleError.isBlank())
                return ApiResponse.error(500, oracleError);

            Long egwtId = ((Number) params.get("egwtId")).longValue();
            LOG.debugf("insert_gwd_well_test succeeded, egwtId=%d", egwtId);
            return ApiResponse.success(egwtId);

        } catch (Exception e) {
            LOG.errorf(e, "insert_gwd_well_test failed");
            return ApiResponse.error(500, "Database error: " + e.getMessage());
        }
    }

    // ── UPDATE ────────────────────────────────────────────────────────────────

    public ApiResponse<Void> update(Long egwtId, GwdWellTestRequest req) {

        if (egwtId == null)
            return ApiResponse.error(400, "egwtId path parameter is required");

        if (req == null)
            return ApiResponse.error(400, "Request body is required");

        if (!DateUtil.isValid(req.wTestStaDt()))
            return ApiResponse.error(400,
                    "Invalid wTestStaDt '%s'. Use yyyy-MM-dd".formatted(req.wTestStaDt()));

        try {
            Map<String, Object> params = buildUpdateParams(egwtId, req);
            wellTestMapper.updateGwdWellTest(params);

            String oracleError = (String) params.get("returnValue");
            if (oracleError != null && !oracleError.isBlank())
                return ApiResponse.error(500, oracleError);

            LOG.debugf("update_gwd_well_test succeeded, egwtId=%d", egwtId);
            return ApiResponse.success(null);

        } catch (Exception e) {
            LOG.errorf(e, "update_gwd_well_test failed, egwtId=%d", egwtId);
            return ApiResponse.error(500, "Database error: " + e.getMessage());
        }
    }

    // ── DELETE ────────────────────────────────────────────────────────────────

    public ApiResponse<Void> delete(Long egwtId) {

        if (egwtId == null)
            return ApiResponse.error(400, "egwtId path parameter is required");

        try {
            Map<String, Object> params = new HashMap<>(Map.of(
                    "egwtId",   egwtId,
                    "doCommit", DO_COMMIT
            ));
            wellTestMapper.deleteGwdWellTest(params);

            String oracleError = (String) params.get("returnValue");
            if (oracleError != null && !oracleError.isBlank())
                return ApiResponse.error(500, oracleError);

            LOG.debugf("delete_gwd_well_test succeeded, egwtId=%d", egwtId);
            return ApiResponse.success(null);

        } catch (Exception e) {
            LOG.errorf(e, "delete_gwd_well_test failed, egwtId=%d", egwtId);
            return ApiResponse.error(500, "Database error: " + e.getMessage());
        }
    }

    // ── private helpers ───────────────────────────────────────────────────────

    private Map<String, Object> buildInsertParams(GwdWellTestRequest req) {
        Map<String, Object> p = new HashMap<>();
        populateCommonParams(p, req);
        p.put("doCommit", DO_COMMIT);
        // OUT params — MyBatis writes these back after the call
        p.put("egwtId",      null);
        p.put("returnValue", null);
        return p;
    }

    private Map<String, Object> buildUpdateParams(Long egwtId, GwdWellTestRequest req) {
        Map<String, Object> p = new HashMap<>();
        populateCommonParams(p, req);
        p.put("egwtId",      egwtId);
        p.put("doCommit",    DO_COMMIT);
        p.put("returnValue", null);
        return p;
    }

    private void populateCommonParams(Map<String, Object> p, GwdWellTestRequest req) {
        p.put("epANum",          req.epANum());
        p.put("rsvrCd",          req.rsvrCd());
        p.put("wHydTestTypCd",   req.wHydTestTypCd());
        p.put("wTestStaDt",      DateUtil.toOracleDate(DateUtil.parse(req.wTestStaDt())));
        p.put("wTemp",           req.wTemp());
        p.put("wHydH2sCnc",      req.wHydH2sCnc());
        p.put("wWtrSaTdsCnc",    req.wWtrSaTdsCnc());
        p.put("wRpm",            req.wRpm());
        p.put("siwhp",           req.siwhp());
        p.put("wHydPmpDpth",     req.wHydPmpDpth());
        p.put("wHydProdRt",      req.wHydProdRt());
        p.put("wStatWlvl",       req.wStatWlvl());
        p.put("wDyncWlvl",       req.wDyncWlvl());
        p.put("testerNetworkId", req.testerNetworkId());
        p.put("wHydProduct",     req.wHydProduct());
        p.put("duration",        req.duration());
    }
}
