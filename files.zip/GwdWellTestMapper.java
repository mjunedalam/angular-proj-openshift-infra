package com.example.gwd.mapper;

import org.apache.ibatis.annotations.Mapper;

import java.util.Map;

/**
 * MyBatis mapper for exad_agwa_iud_pkg well-test procedures.
 *
 * All methods accept a mutable Map so MyBatis can write OUT params back:
 *   insert → writes "egwtId" and "returnValue"
 *   update → writes "returnValue"
 *   delete → writes "returnValue"
 */
@Mapper
public interface GwdWellTestMapper {

    void insertGwdWellTest(Map<String, Object> params);

    void updateGwdWellTest(Map<String, Object> params);

    void deleteGwdWellTest(Map<String, Object> params);
}
