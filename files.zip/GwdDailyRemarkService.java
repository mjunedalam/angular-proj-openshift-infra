package com.example.gwd.service;

import com.example.gwd.dto.ApiResponse;
import com.example.gwd.dto.GwdDailyRemarkRequest;
import com.example.gwd.mapper.GwdDailyRemarkMapper;
import com.example.gwd.util.DateUtil;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import org.jboss.logging.Logger;

import java.util.HashMap;
import java.util.Map;

@ApplicationScoped
public class GwdDailyRemarkService {

    private static final Logger LOG       = Logger.getLogger(GwdDailyRemarkService.class);
    private static final String DO_COMMIT = "Y";

    @Inject
    GwdDailyRemarkMapper dailyRemarkMapper;

    // ── INSERT ────────────────────────────────────────────────────────────────

    public ApiResponse<Long> insert(GwdDailyRemarkRequest req) {

        if (req == null)
            return ApiResponse.error(400, "Request body is required");

        if (!DateUtil.isValid(req.wActDt()))
            return ApiResponse.error(400,
                    "Invalid wActDt '%s'. Use yyyy-MM-dd".formatted(req.wActDt()));

        try {
            Map<String, Object> params = buildInsertParams(req);
            dailyRemarkMapper.insertGwdDailyRemark(params);

            String oracleError = (String) params.get("returnValue");
            if (oracleError != null && !oracleError.isBlank())
                return ApiResponse.error(500, oracleError);

            Long egdrId = ((Number) params.get("egdrId")).longValue();
            LOG.debugf("insert_gwd_daily_remark succeeded, egdrId=%d", egdrId);
            return ApiResponse.success(egdrId);

        } catch (Exception e) {
            LOG.errorf(e, "insert_gwd_daily_remark failed");
            return ApiResponse.error(500, "Database error: " + e.getMessage());
        }
    }

    // ── UPDATE ────────────────────────────────────────────────────────────────

    public ApiResponse<Void> update(Long egdrId, GwdDailyRemarkRequest req) {

        if (egdrId == null)
            return ApiResponse.error(400, "egdrId path parameter is required");

        if (req == null)
            return ApiResponse.error(400, "Request body is required");

        if (!DateUtil.isValid(req.wActDt()))
            return ApiResponse.error(400,
                    "Invalid wActDt '%s'. Use yyyy-MM-dd".formatted(req.wActDt()));

        try {
            Map<String, Object> params = buildUpdateParams(egdrId, req);
            dailyRemarkMapper.updateGwdDailyRemark(params);

            String oracleError = (String) params.get("returnValue");
            if (oracleError != null && !oracleError.isBlank())
                return ApiResponse.error(500, oracleError);

            LOG.debugf("update_gwd_daily_remark succeeded, egdrId=%d", egdrId);
            return ApiResponse.success(null);

        } catch (Exception e) {
            LOG.errorf(e, "update_gwd_daily_remark failed, egdrId=%d", egdrId);
            return ApiResponse.error(500, "Database error: " + e.getMessage());
        }
    }

    // ── DELETE ────────────────────────────────────────────────────────────────

    public ApiResponse<Void> delete(Long egdrId) {

        if (egdrId == null)
            return ApiResponse.error(400, "egdrId path parameter is required");

        try {
            Map<String, Object> params = new HashMap<>(Map.of(
                    "egdrId",    egdrId,
                    "doCommit",  DO_COMMIT
            ));
            dailyRemarkMapper.deleteGwdDailyRemark(params);

            String oracleError = (String) params.get("returnValue");
            if (oracleError != null && !oracleError.isBlank())
                return ApiResponse.error(500, oracleError);

            LOG.debugf("delete_gwd_daily_remark succeeded, egdrId=%d", egdrId);
            return ApiResponse.success(null);

        } catch (Exception e) {
            LOG.errorf(e, "delete_gwd_daily_remark failed, egdrId=%d", egdrId);
            return ApiResponse.error(500, "Database error: " + e.getMessage());
        }
    }

    // ── private helpers ───────────────────────────────────────────────────────

    private Map<String, Object> buildInsertParams(GwdDailyRemarkRequest req) {
        Map<String, Object> p = new HashMap<>();
        populateCommonParams(p, req);
        p.put("doCommit",    DO_COMMIT);
        p.put("egdrId",      null);
        p.put("returnValue", null);
        return p;
    }

    private Map<String, Object> buildUpdateParams(Long egdrId, GwdDailyRemarkRequest req) {
        Map<String, Object> p = new HashMap<>();
        populateCommonParams(p, req);
        p.put("egdrId",      egdrId);
        p.put("doCommit",    DO_COMMIT);
        p.put("returnValue", null);
        return p;
    }

    private void populateCommonParams(Map<String, Object> p, GwdDailyRemarkRequest req) {
        p.put("epANum",         req.epANum());
        p.put("wActDt",         DateUtil.toOracleDate(DateUtil.parse(req.wActDt())));
        p.put("area",           req.area());
        p.put("status",         req.status());
        p.put("wOpRmk",         req.wOpRmk());
        p.put("nxt24HrPlanRmk", req.nxt24HrPlanRmk());
        p.put("wDrlgSmryRmk",   req.wDrlgSmryRmk());
    }
}
