package com.example.gwd.resource;

import com.example.gwd.dto.ApiResponse;
import com.example.gwd.dto.GwdWellTestRequest;
import com.example.gwd.service.GwdWellTestService;
import jakarta.inject.Inject;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;

/**
 * REST resource for GWD Well Test operations.
 *
 * POST   /api/gwd-well-tests           → insert_gwd_well_test  (returns generated egwtId)
 * PUT    /api/gwd-well-tests/{egwtId}  → update_gwd_well_test
 * DELETE /api/gwd-well-tests/{egwtId}  → delete_gwd_well_test
 */
@Path("/api/gwd-well-tests")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class GwdWellTestResource {

    @Inject
    GwdWellTestService wellTestService;

    @POST
    public ApiResponse<Long> insert(GwdWellTestRequest request) {
        return wellTestService.insert(request);
    }

    @PUT
    @Path("/{egwtId}")
    public ApiResponse<Void> update(@PathParam("egwtId") Long egwtId, GwdWellTestRequest request) {
        return wellTestService.update(egwtId, request);
    }

    @DELETE
    @Path("/{egwtId}")
    public ApiResponse<Void> delete(@PathParam("egwtId") Long egwtId) {
        return wellTestService.delete(egwtId);
    }
}
