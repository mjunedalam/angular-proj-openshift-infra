package com.example.gwd.resource;

import com.example.gwd.dto.ApiResponse;
import com.example.gwd.dto.GwdDailyRemarkRequest;
import com.example.gwd.service.GwdDailyRemarkService;
import jakarta.inject.Inject;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;

/**
 * REST resource for GWD Daily Remark operations.
 *
 * POST   /api/gwd-daily-remarks           → insert_gwd_daily_remark  (returns generated egdrId)
 * PUT    /api/gwd-daily-remarks/{egdrId}  → update_gwd_daily_remark
 * DELETE /api/gwd-daily-remarks/{egdrId}  → delete_gwd_daily_remark
 */
@Path("/api/gwd-daily-remarks")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class GwdDailyRemarkResource {

    @Inject
    GwdDailyRemarkService dailyRemarkService;

    @POST
    public ApiResponse<Long> insert(GwdDailyRemarkRequest request) {
        return dailyRemarkService.insert(request);
    }

    @PUT
    @Path("/{egdrId}")
    public ApiResponse<Void> update(@PathParam("egdrId") Long egdrId, GwdDailyRemarkRequest request) {
        return dailyRemarkService.update(egdrId, request);
    }

    @DELETE
    @Path("/{egdrId}")
    public ApiResponse<Void> delete(@PathParam("egdrId") Long egdrId) {
        return dailyRemarkService.delete(egdrId);
    }
}
