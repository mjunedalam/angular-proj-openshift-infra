package com.example.gwd.mapper;

import org.apache.ibatis.annotations.Mapper;

import java.util.Map;

/**
 * MyBatis mapper for exad_agwa_iud_pkg daily-remark procedures.
 *
 * All methods accept a mutable Map so MyBatis can write OUT params back:
 *   insert → writes "egdrId" and "returnValue"
 *   update → writes "returnValue"
 *   delete → writes "returnValue"
 */
@Mapper
public interface GwdDailyRemarkMapper {

    void insertGwdDailyRemark(Map<String, Object> params);

    void updateGwdDailyRemark(Map<String, Object> params);

    void deleteGwdDailyRemark(Map<String, Object> params);
}
